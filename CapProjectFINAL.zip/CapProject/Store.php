<?php
$dbHost = "localhost";
$dbUser = "root";
$dbPassword = "password";
$dbName = "moonlitgames";
$data = null;

try 
{
$dsn = "mysql:host=" . $dbHost . ";dbname=" . $dbName;
$connect = new PDO($dsn, $dbUser, $dbPassword);
}
catch(PDOException $e)
{
	echo "Connection Failed: " . $e->getMessage();
}
$query1 = "SELECT prod_stock FROM prod_table WHERE prod_id = ?";	//query
$retrieve1 = $connect->prepare($query1);    //Switch pull
$retrieve1->execute([59]);
$data1 = $retrieve1->fetchColumn();

$query2 = "SELECT prod_stock FROM prod_table WHERE prod_id = ?";	//query
$retrieve2 = $connect->prepare($query2);    //PS4 pull
$retrieve2->execute([60]);
$data2 = $retrieve2->fetchColumn();

$query3 = "SELECT prod_stock FROM prod_table WHERE prod_id = ?";	//query
$retrieve3 = $connect->prepare($query3);    //Xbone pull
$retrieve3->execute([61]);
$data3 = $retrieve3->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Store</title>
	<link rel="stylesheet" href="style.css"> 
  </head>
  <body>
  
<div class="nav">
	<img class="logo" src="logo.png">
  	<a href="index.html">Home</a>
	<a class="active" href="Store.php">Store</a>
	<a href="Login.php">Login</a>
	<a href="register.php">Register</a>
	<a href="About.html">About Us</a>
	<a href="Contact.html">Contact Information</a>
	<a href="loginSuccess.php">Inventory</a>
</div>

<div class="page"> 
<h2>Store</h2>
</div>
<div class="pagebody">
<div class="row">
  <div class="columnstore">
  <img class="switch" src="switch.jpg" style="margin-left:5px;margin-right:5px;height:75px;width:100px;float:left;clear:left;">
    <h2>Nintendo Switch</h2>
    <p>Price: $300.00<br>
	Stock Availiable: <?php echo $data1;?></p>
  </div>
  <div class="columnstore">
  <img class="ps4" src="ps4.jpg" style="margin-left:5px;margin-right:5px;height:75px;width:100px;float:left;clear:left;">
    <h2>Playstation 4</h2>
    <p>Price: $299.99<br>
	Stock Availiable: <?php echo $data2;?></p>
  </div>
</div>
<div class="row">
  <div class="columnstore">
  <img class="xbox" src="xbox.jpg" style="margin-left:5px;margin-right:5px;height:75px;width:100px;float:left;clear:left;">
    <h2>Xbox One</h2>
    <p>Price: $250.00<br>
	Stock Availiable: <?php echo $data3;?></p>
  </div>
</div>
</div>

</table>
</body>
</html>
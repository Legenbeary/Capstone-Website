$connection = new PDO();
<!doctype html> 
<html lang="en">
	<head>
		<meta charset="utf-8" />
	<head>
		<title>Logged In</title>
	</head>
	<body>
		<h1>
			You are now logged in
		</h1>
		<h2>
			<p>
				<a class="btn btn-secondary" href="index.html" role="button">Return to Home &raquo;</a>
			</p>
		</h2>
	</body>
</html> 
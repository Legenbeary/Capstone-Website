-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2020 at 04:11 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moonlitgames`
--

-- --------------------------------------------------------

--
-- Table structure for table `prod_table`
--

CREATE TABLE `prod_table` (
  `prod_id` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `prod_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prod_table`
--

INSERT INTO `prod_table` (`prod_id`, `product`, `prod_stock`) VALUES
(3, 'Test G4me 3', 18),
(4, 'Test Game 4', 10),
(24, 'Test Game 6', 3),
(25, 'Test Game 7', 2),
(28, 'Test Game 8', 20),
(32, 'Test Game 9', 1),
(34, 'Test Game 10', 2),
(35, 'Test Game 11', 20),
(36, 'Test Game 12', 5),
(37, 'Test Game 13', 40),
(38, 'Test Game 14', 20),
(39, 'Test Game 15', 50),
(40, 'Test Game 16', 12),
(41, 'Test Game 17', 5),
(44, 'Test Game 18', 50),
(57, 'Test Game 19', 16),
(59, 'Nintendo Switch', 12),
(60, 'Playstation 4', 35),
(61, 'Xbox One', 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'Jack', 'Password1!'),
(2, 'Brittney', 'password'),
(3, 'John', 'password'),
(5, 'Linda', 'password'),
(6, 'Belle', 'password'),
(7, 'Charles', 'Strongp1!');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prod_table`
--
ALTER TABLE `prod_table`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prod_table`
--
ALTER TABLE `prod_table`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

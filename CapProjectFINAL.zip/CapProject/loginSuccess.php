<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Store</title>
	<link rel="stylesheet" href="style.css"> 
  </head>
  <body>
  
<div class="nav">
	<img class="logo" src="logo.png">
	<a href="index.html">Home</a>
	<a href="Store.php">Store</a>
	<a href="Login.php">Login</a>
	<a href="register.php">Register</a>
	<a href="About.html">About Us</a>
	<a href="Contact.html">Contact Information</a>
	<a class="active" href="loginSuccess.php">Inventory</a>
</div>

<?php
$dbHost = "localhost";
$dbUser = "root";
$dbPassword = "password";
$dbName = "moonlitgames";
$data = null;

try 
{
$dsn = "mysql:host=" . $dbHost . ";dbname=" . $dbName;
$connect = new PDO($dsn, $dbUser, $dbPassword);
}
catch(PDOException $e)
{
	echo "Connection Failed: " . $e->getMessage();
}
$query = "select * from prod_table";	//query
$retrieve = $connect->query($query);    //query entry upon connection


if(isset($_POST["add"])) //checks for "enter" button press
{ 
	$product = $_POST['product'];
	$prod_stock = $_POST['prod_stock'];
	
  if(empty($product) || empty($prod_stock)) 
  {
	echo "<script>					
			alert('All fields required');
		  </script>";
  } 
  else
  {
		$query2 = "INSERT INTO prod_table (product, prod_stock) VALUES (:product, :prod_stock)";
		$retrieve2 = $connect->prepare($query2);
      
		$retrieve2->execute(['product' => $product, 'prod_stock' => $prod_stock]);

		$name = "";
		$prod_stock = "";
	
		echo "<script>					
				alert('Product added');
			</script>";	
  }		
	
 }
?>
<?php
if(isset($_POST["search"])) //checks for search button press 
{   
	$search = $_POST['searchProduct'];
	
	$stmt = $connect->prepare("SELECT * FROM prod_table WHERE product LIKE '%".$search."%'"); 
	$stmt->execute();
	$data = $stmt->fetchAll(PDO::FETCH_ASSOC);	//stores all relevent data in array
}
?>
<?php
if(isset($_POST["delete"])) //checks for delete button press 
{  
		$delete = $_POST['remProduct'];
		
	    if(empty($delete)) 
		{
			echo "<script>					
					alert('All fields required');
				  </script>";
		} 
		else
		{
		
	
			$connect->exec("DELETE FROM prod_table WHERE product = '".$delete."'");

			echo "<script>					
					alert('Product removed');
				  </script>";
		}	
}
?>

<?php
if(isset($_POST["edit1"])) //check for edit1 button press
{	
		$chProduct = $_POST['chProduct'];
		$editProd = $_POST['editProd'];   
		
	    if(empty($chProduct) || empty($editProd)) 
		{
			echo "<script>					
					alert('All fields required');
				  </script>";
		} 
		else
		{	
			$connect->exec("UPDATE prod_table SET product = '".$editProd."' WHERE product = '".$chProduct."'");
	
			echo "<script>					
					alert('Product name updated');
				  </script>";
		}		  
}
?>

<?php
if(isset($_POST["edit2"])) //check for edit2 button press
{
		$chProduct = $_POST['chProduct'];
		$editStock = $_POST['editStock'];	
		
	    if(empty($chProduct) || empty($editStock))  
		{
			echo "<script>					
					alert('All fields required');
				  </script>";
		} 
		else
		{		
			$connect->exec("UPDATE prod_table SET prod_stock = '".$editStock."' WHERE product = '".$chProduct."'");
	
			echo "<script>					
					alert('Product stock updated');
				  </script>";
		}		  
}
?>
<?php	//Session verification
session_start();

if(isset($_SESSION["username"]))
{														//welcome text and logout option
	echo '<table style="margin-right: 25px; width: 400px" align="right">';
		echo '<tr >';
			echo '<td>Welcome '.$_SESSION["username"].'</td>';
			echo '<td><a href="passChange.php">Change Password</a></td>';
			echo '<td><a href="logout.php">Logout</a></td>';
		echo '</tr>';
	echo '</table>';	
}
else
{
	//alert message and page redirect if not logged in
echo "<script>					
		alert('Please log in');
		window.location.href='Login.php';
	  </script>";
	
}	

?>
<br><br>
<div style="margin-left: 25px; margin-right: 25px;">
	<div style="margin-left: 50px; width: 350px; float:left; background-color: white">
		<h2 style="color:#373737">
			Search Inventory
		</h2>
		<h2 style="font-size: .8em">
			&#40Leave blank and hit enter to show all&#41
		</h2>

		<form method="POST" >
			<input type="text" title="searchProduct" name="searchProduct" placeholder="Product"/>
			<button type="submit" name="search" class="btn" value="Search";>
				Enter
			</button>
		</form>

		<h2 style="color:#373737">
			Add Product
		</h2>

		<form method="POST">
			<input type="text" title="product" name="product" placeholder="Product"/>
			<input type="number" title="prod_stock" name="prod_stock" placeholder="stock"/>
			<button type="submit" name="add" class="btn" value="Add";>
				Enter
			</button>
		</form>
		
		<h2 style="color:#373737">
			Remove Product
		</h2>

		<form method="POST">
			<input type="text" title="remProduct" name="remProduct" placeholder="Remove Product"/>
			<button type="submit" name="delete" class="btn" value="Delete";>
				Enter
			</button>
		</form>
	
		<h2 style="color:#373737">
			Edit Product Name
		</h2>

		<form method="POST">
			<input type="text" title="chProduct" name="chProduct" placeholder="Choose Product"/>
			<input type="text" title="editProd" name="editProd" placeholder="New Product Name"/>
			<button type="submit" name="edit1" class="btn" value="Edit1";>
				Enter
			</button>
		</form>	
	
		<h2 style="color:#373737">
			Edit Product Stock
		</h2>
	
		<form method="POST">
			<input type="text" title="chProduct" name="chProduct" placeholder="Choose Product"/>
			<input type="text" title="editStock" name="editStock" placeholder="New Stock Value"/>
			<button type="submit" name="edit2" class="btn" value="Edit2";>
				Enter
			</button>
		</form>
		
		
		<br>
		<!--
		<form>
			<button type="submit" name="showAll" class="btn" value="ShowAll";>
				Show All
			</button>
		</form>-->
	</div>
	<div style"float:right">
		<?php 

		if(is_array($data)) //checks to see if array is created yet
		{	
		?>	<!--Table for search results echo-->		
			<table style="background-color:white; margin: 0 auto">	
				<tr>
					<th>
						Product ID				
					</th>
					
					<th>
						Product
					</th>
				
					<th>
						Stock
					</th>
				</tr>
				<?php foreach($data as $row): ?>
				<tr>	
					<td><?=$row['prod_id']?></td>
					<td><?=$row['product']?></td>
					<td><?=$row['prod_stock']?></td>
				</tr>
				<?php endforeach ?>
			</table>	
		<?php }?>
	<div>
</div>	
  </body>
</html>
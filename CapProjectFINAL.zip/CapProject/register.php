
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>
	<link rel="stylesheet" href="style.css"> 
  </head>
  <body>

	<div class="nav">
		<img class="logo" src="logo.png">
		<a href="index.html">Home</a>
		<a href="Store.php">Store</a>
		<a href="Login.php">Login</a>
		<a class="active" href="register.php">Register</a>
		<a href="About.html">About Us</a>
		<a href="Contact.html">Contact Information</a>
		<a href="loginSuccess.php">Inventory</a>
	</div>
	<?php
//if submit button pressed keep going 
if(isset($_POST["registerbtn"]))
{
$hostname='localhost';
$username='root';
$password='password';

$newUser = $_POST['regUsername'];
$passOne = $_POST['regPsw'];
$passTwo = $_POST['pswRepeat'];

//password strength validation
$uppercase = preg_match('@[A-Z]@', $passOne);
$lowercase = preg_match('@[a-z]@', $passOne);
$number    = preg_match('@[0-9]@', $passOne);
$specialChars = preg_match('@[^\w]@', $passOne);

	//check for correct password reentry
	if($passOne !== $passTwo)
	{
		echo "<p><font color=red>passwords do not match</p>";
	}
	//check for strong password
	if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($passOne) < 8) 
	{
		echo 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
	}	
	else
	{
		try 
		{
			$connect = new PDO("mysql:host=$hostname;dbname=moonlitgames",$username,$password);
			// query that inserts data into table
			$sqlReg = "INSERT INTO users (username, password)
					VALUES ('".$_POST["regUsername"]."','".$_POST["regPsw"]."')";	
				
			//check for successful entry
			if ($connect->query($sqlReg)) 
			{
				echo "<script>					
						alert('Registration successful');
						window.location.href='Login.php';
					  </script>";
			}
			else
			{
				echo "<p><font color=red>Username is already in use</p>";
			}
	
			$connect = null;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
}
?>
 	<?php
		if(isset($message))
		{
			echo '<label style="color:red; background-color:black;">'.$message.'</label>';
		}
	?>	
	<div class="log-form">
	<h2>
		Create new account
	</h2>
  <!-- Login cred block -->
	<form method="post">
		<input type="text" title="username" name="regUsername" placeholder="username" class="form-control" />
		<input type="password" title="password" name="regPsw" placeholder="password" class="form-control" />
		<input type="password" title="password" name="pswRepeat" placeholder="repeat password" class="form-control" required/>
		<button type="submit" name="registerbtn" class="btn" value="Login">
			Create Account
		</button>
	</form>
	
	</div><!--end log form -->
			
  </body>
</html>
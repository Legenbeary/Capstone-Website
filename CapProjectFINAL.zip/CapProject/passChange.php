<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Store</title>
	<link rel="stylesheet" href="style.css"> 
  </head>
  <body>
  
<div class="nav">
	<img class="logo" src="logo.png">
	<a href="index.html">Home</a>
	<a href="Store.php">Store</a>
	<a href="Login.php">Login</a>
	<a href="register.php">Register</a>
	<a href="About.html">About Us</a>
	<a href="Contact.html">Contact Information</a>
	<a class="active" href="loginSuccess.php">Inventory</a>
</div>

<?php	//Session verification
session_start();

if(isset($_SESSION["username"]))
{														//welcome text and logout option
	echo '<table align="right" bgcolor="white">';
		echo '<tr >';
			echo '<td>Welcome '.$_SESSION["username"].'</td>';
			echo '<td>&nbsp</td>';
			echo '<td><a href="logout.php">Logout</a></td>';
		echo '</tr>';
	echo '</table>';
		if(isset($_POST["passChange"]))
		{
			$hostname='localhost';
			$username='root';
			$password='password';


			$passOne = $_POST['password'];
			$passTwo = $_POST['rePassword'];

			//password strength validation
			$uppercase = preg_match('@[A-Z]@', $passOne);
			$lowercase = preg_match('@[a-z]@', $passOne);
			$number    = preg_match('@[0-9]@', $passOne);
			$specialChars = preg_match('@[^\w]@', $passOne);

			//check for correct password reentry
			if($passOne !== $passTwo)
			{
				echo "<p><font color=red>passwords do not match</p>";
			}
			//check for strong password
			if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($passOne) < 8) 
			{
				echo 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
			}	
			else
			{
				try 
				{
					$connect = new PDO("mysql:host=$hostname;dbname=moonlitgames",$username,$password);
					// query that inserts data into table
					$sqlChP = "UPDATE users SET password='".$_POST['password']."'
							WHERE username='".$_SESSION["username"]."'";	
							
					
					//check for successful entry
					if ($connect->query($sqlChP)) 
					{
						echo "<script>					
								alert('Password Changed');
								window.location.href='loginSuccess.php';
							  </script>";
					}
					else
					{
						echo "<p><font color=red>Error</p>";
					}
		
					$connect = null;
				}
				catch(PDOException $e)
				{
					echo $e->getMessage();
				}
			}
		}
}
else
{
	//alert message and page redirect if not logged in
echo "<script>					
		alert('Please log in');
		window.location.href='Login.php';
	  </script>";
	
}	

?>
<div class="log-form">
	<h2>
		Change Password
	</h2>
	<form method="post">
		<input type="text" title="password" name="password" placeholder="New Password" class="form-control" required/>
		<input type="password" title="rePassword" name="rePassword" placeholder="Re-type password" class="form-control" required/>
		<button type="submit" name="passChange" class="btn" value="PassChange">
			Change Password
		</button>
	</form>
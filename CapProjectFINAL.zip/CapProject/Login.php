<?php
session_start();  #create session
$host = "localhost";
$username = "root";							#database name is moonlitgames with table named users
$password = "password";						#the 3 columns are user_id (auto-incremented), username, and password
$database = "moonlitgames";
$message = "";

try
{
	#create connection variable
	$connect = new PDO("mysql:host=$host; dbname=$database", $username, $password); 
	$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_POST["login"])) #checks for button press
	{
		if(empty($_POST["username"]) || empty($_POST["password"])) #if fields are empty throw message
		{
			$message = '<label>All fields are required</label>';
		}
		else			#checks for matching credentials in db
		{
			$query = "SELECT * FROM users WHERE username = :username AND password = :password";
			$statement = $connect->prepare($query);
			$statement->execute(
				array(
					'username' => $_POST["username"],
					'password' => $_POST["password"]
				)
			);
			$count = $statement->rowCount();		
			if($count > 0)   #sends to new page upon successful check
			{
				$_SESSION["username"] = $_POST["username"];
				header("location:loginSuccess.php");
			}
			else
			{
				$message = '<label>Username or Password is incorrect</label>';
			}
		}
	}
}
	catch(PDOEXCEPTION $error)
	{
		$message = $error->getMessage();
	}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>
	<link rel="stylesheet" href="style.css"> 
  </head>
  <body>

	<div class="nav">
		<img class="logo" src="logo.png">
		<a href="index.html">Home</a>
		<a href="Store.php">Store</a>
		<a class="active" href="Login.php">Login</a>
		<a href="register.php">Register</a>
		<a href="About.html">About Us</a>
		<a href="Contact.html">Contact Information</a>
		<a href="loginSuccess.php">Inventory</a>
	</div>
 	<?php
		if(isset($message))
		{
			echo '<label style="color:red; background-color:black;">'.$message.'</label>';
		}
	?>	
	<div class="log-form">
	<h2>
		Login to your account
	</h2>
  <!-- Login cred block -->
	<form method="post">
		<input type="text" title="username" name="username" placeholder="username" class="form-control" required/>
		<input type="password" title="password" name="password" placeholder="password" class="form-control" required/>
		<button type="submit" name="login" class="btn" value="Login">
			Login
		</button>
		<!--<a class="forgot" href="#">		#no point showing this right now
			Forgot Username?
		</a>-->
	</form>
	
	</div><!--end log form -->
			
  </body>
</html>